"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { MessageCircle, ChevronDown, ChevronUp } from "lucide-react"
import { useTranslation } from "react-i18next"
import Image from "next/image"

const faqs = [
  {
    question: "What is an eSIM?",
    answer:
      "An eSIM (embedded SIM) is a digital SIM that allows you to activate a cellular plan without using a physical SIM card. It's built into your device and can be easily programmed to work with different carriers.",
  },
  {
    question: "How do I install my eSIM?",
    answer:
      "After purchase, you'll receive a QR code. Go to your phone's settings, select 'Add Cellular Plan' or 'Add eSIM', and scan the QR code. Follow the on-screen instructions to complete the installation.",
  },
  {
    question: "Which devices are compatible?",
    answer:
      "Most recent smartphones support eSIM, including iPhone XS and newer, Google Pixel 3 and newer, and Samsung Galaxy S20 and newer. Check our compatibility section below for more details.",
  },
  {
    question: "How long does activation take?",
    answer:
      "eSIM activation typically takes just a few minutes. Once you scan the QR code and follow the setup process, you should be connected almost immediately.",
  },
]

const compatibleDevices = [
  {
    name: "iPhone 13",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/iphone-13-IfSBodyc5DwPCkjKwPQN3T34Fn75OU.jpg",
  },
  {
    name: "Samsung Galaxy S21",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/samsung-s21-IfSBodyc5DwPCkjKwPQN3T34Fn75OU.jpg",
  },
  {
    name: "Google Pixel 6",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pixel-6-IfSBodyc5DwPCkjKwPQN3T34Fn75OU.jpg",
  },
]

export default function Support() {
  const { t } = useTranslation()
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [isChatOpen, setIsChatOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 pb-24">
      <div className="container mx-auto max-w-4xl">
        <h1 className="text-4xl font-bold text-center mb-12">{t("support")}</h1>

        {/* FAQ Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">{t("frequentlyAskedQuestions")}</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div key={index} className="bg-white rounded-lg shadow-md overflow-hidden" initial={false}>
                <button
                  className="w-full px-6 py-4 text-left flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <span className="font-medium">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: openFaq === index ? "auto" : 0 }}
                  className="overflow-hidden"
                >
                  <p className="px-6 pb-4">{faq.answer}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Compatible Devices Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">{t("compatibleDevices")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {compatibleDevices.map((device, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <Image
                  src={device.image || "/placeholder.svg"}
                  alt={device.name}
                  width={300}
                  height={300}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold">{device.name}</h3>
                  <p className="text-sm text-gray-600">eSIM Compatible</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Live Chat Button */}
        <motion.button
          className="fixed bottom-20 right-8 bg-[#00ACCD] text-white p-4 rounded-full shadow-lg hover:bg-[#0090AB] transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsChatOpen(!isChatOpen)}
        >
          <MessageCircle size={24} />
        </motion.button>

        {/* Chat Window */}
        {isChatOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-36 right-8 w-96 h-96 bg-white rounded-lg shadow-xl"
          >
            <div className="p-4 bg-[#00ACCD] text-white rounded-t-lg flex justify-between items-center">
              <h3 className="font-semibold">{t("liveChatSupport")}</h3>
              <button onClick={() => setIsChatOpen(false)}>&times;</button>
            </div>
            <div className="p-4 h-72 overflow-y-auto">
              {/* Chat messages would go here */}
              <p className="text-center text-gray-500">Chat support coming soon...</p>
            </div>
            <div className="p-4 border-t">
              <input type="text" placeholder="Type your message..." className="w-full p-2 border rounded-lg" disabled />
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

