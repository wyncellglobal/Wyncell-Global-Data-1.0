"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useTranslation } from "react-i18next"
import { loadStripe } from "@stripe/stripe-js"
import { Elements, CardElement, useStripe, useElements } from "@stripe/react-stripe-js"
import Image from "next/image"
import { Trash2 } from "lucide-react"

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

interface CartItem {
  id: number
  name: string
  price: number
  image: string
  quantity: number
  type: "plan" | "device"
}

function CheckoutForm({
  cartItems,
  removeItem,
  total,
}: { cartItems: CartItem[]; removeItem: (id: number) => void; total: number }) {
  const { t } = useTranslation()
  const stripe = useStripe()
  const elements = useElements()
  const [error, setError] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    setProcessing(true)

    const cardElement = elements.getElement(CardElement)

    if (cardElement) {
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
      })

      if (error) {
        setError(error.message || "An error occurred")
        setProcessing(false)
      } else {
        // Here you would typically send the paymentMethod.id to your server
        // to create a charge or save the payment method for later use
        console.log("PaymentMethod", paymentMethod)
        setProcessing(false)
        // Redirect to a success page or show a success message
      }
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">{t("orderSummary")}</h2>
        <div className="bg-gray-100 p-4 rounded-lg">
          {cartItems.map((item) => (
            <div key={item.id} className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  width={50}
                  height={50}
                  className="mr-2 rounded-md"
                />
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p>
                    ${item.price.toFixed(2)} x {item.quantity}
                  </p>
                </div>
              </div>
              <button
                onClick={() => removeItem(item.id)}
                className="text-red-500 hover:text-red-700"
                aria-label={t("remove")}
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}
          <div className="border-t pt-2 mt-2">
            <p className="font-semibold text-lg text-right">
              {t("total")}: ${total.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <label htmlFor="card-element" className="block text-sm font-medium text-gray-700 mb-2">
          {t("cardDetails")}
        </label>
        <div className="border rounded-md p-3">
          <CardElement id="card-element" options={{ style: { base: { fontSize: "16px" } } }} />
        </div>
      </div>
      {error && <div className="text-red-500 mb-4">{error}</div>}
      <button
        type="submit"
        disabled={!stripe || processing || cartItems.length === 0}
        className="w-full bg-[#00ACCD] text-white px-6 py-3 rounded-full hover:bg-[#0090AB] transition-colors disabled:opacity-50"
      >
        {processing ? t("processing") : `${t("pay")} $${total.toFixed(2)}`}
      </button>
    </form>
  )
}

export default function Checkout() {
  const { t } = useTranslation()
  const [cartItems, setCartItems] = useState<CartItem[]>([])

  useEffect(() => {
    // In a real application, you would fetch the cart items from your state management solution or API
    const mockCartItems: CartItem[] = [
      { id: 1, name: "10GB Data Plan - Spain", price: 29.99, image: "/images/esim.png", quantity: 1, type: "plan" },
      { id: 2, name: "iPhone 13", price: 799, image: "/images/devices/iphone-13.jpg", quantity: 1, type: "device" },
    ]
    setCartItems(mockCartItems)
  }, [])

  const removeItem = (id: number) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id))
  }

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t("checkout")}</h1>
      <Elements stripe={stripePromise}>
        <CheckoutForm cartItems={cartItems} removeItem={removeItem} total={total} />
      </Elements>
    </div>
  )
}

