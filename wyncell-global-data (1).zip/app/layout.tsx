import type React from "react"
import { I18nProvider } from "./components/I18nProvider"
import SharedHeader from "./components/SharedHeader"
import SharedFooter from "./components/SharedFooter"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="flex flex-col min-h-screen">
        <I18nProvider>
          <SharedHeader />
          <main className="flex-grow">{children}</main>
          <SharedFooter />
        </I18nProvider>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
