import axios from "axios"

interface ExchangeRates {
  [key: string]: number
}

let exchangeRates: ExchangeRates = {}

export async function fetchExchangeRates(): Promise<void> {
  try {
    const response = await axios.get("https://api.exchangerate-api.com/v4/latest/GBP")
    exchangeRates = response.data.rates
  } catch (error) {
    console.error("Error fetching exchange rates:", error)
  }
}

export function convertCurrency(amount: number, fromCurrency: string, toCurrency: string): number {
  if (fromCurrency === toCurrency) return amount
  if (!exchangeRates[fromCurrency] || !exchangeRates[toCurrency]) return amount

  const amountInGBP = amount / exchangeRates[fromCurrency]
  return amountInGBP * exchangeRates[toCurrency]
}

export async function getUserCurrency(): Promise<string> {
  try {
    const response = await axios.get("https://ipapi.co/json/")
    return response.data.currency
  } catch (error) {
    console.error("Error fetching user currency:", error)
    return "GBP" // Default to GBP if there's an error
  }
}

export const currencySymbols: { [key: string]: string } = {
  GBP: "£",
  USD: "$",
  EUR: "€",
  JPY: "¥",
  // Add more currency symbols as needed
}

