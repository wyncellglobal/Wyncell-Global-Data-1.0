"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { useTranslation } from "react-i18next"

const testimonials = [
  {
    name: "Daniella Mejia",
    rating: 5,
    text: "The price and the connectivity were excellent - never again will I use roaming!",
    avatar: "/avatars/daniella.jpg",
  },
  // Add more testimonials here
]

const newsItems = [
  {
    title: "How Much % Cost of Data and How Long Will It Last",
    image: "/news/data-cost.jpg",
    date: "October 15, 2023",
    excerpt: "Understanding data consumption and planning your usage effectively...",
  },
  {
    title: "What is 5G?",
    image: "/news/5g.jpg",
    date: "October 10, 2023",
    excerpt: "Understanding the future of mobile networking...",
  },
  {
    title: "What is GSM?",
    image: "/news/gsm.jpg",
    date: "October 5, 2023",
    excerpt: "Understanding the fundamentals of mobile communications...",
  },
]

const activationSteps = [
  "Check if your phone is eSIM compatible",
  "Place your order and receive your QR code",
  "Scan your QR code and follow the prompts",
  "Start using your eSIM!",
]

export default function Home() {
  const { t } = useTranslation()
  const [currentTestimonial, setCurrentTestimonial] = useState(0)

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-[#00B6D6] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#C4D600] rounded-full transform translate-x-1/2 -translate-y-1/2" />
        <div className="container mx-auto px-4 py-16">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Welcome to
                <br />
                Wyncell Telecom
              </h1>
              <p className="text-white text-lg mb-8">Your affordable trusted provider</p>
              <Link
                href="/plans"
                className="bg-white text-[#00B6D6] px-8 py-3 rounded-full font-semibold hover:bg-opacity-90 transition-colors"
              >
                View Our Plans
              </Link>
            </div>
            <div className="md:w-1/2 mt-8 md:mt-0">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/sim-cards-nmRkExoPYDMYJMku2tQxuZIuvvsYQX.png"
                alt="Wyncell SIM Cards"
                width={500}
                height={300}
                className="w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* What is Wyncell Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/3">
              <div className="bg-[#C4D600] rounded-full p-8 w-48 h-48 flex items-center justify-center mx-auto">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/sim-icon-nmRkExoPYDMYJMku2tQxuZIuvvsYQX.png"
                  alt="SIM Icon"
                  width={100}
                  height={100}
                />
              </div>
            </div>
            <div className="md:w-2/3">
              <h2 className="text-3xl font-bold mb-4">What is Wyncell?</h2>
              <p className="text-gray-600 mb-6">
                Founded in 2022, we set out with a mission to provide affordable, reliable, high-quality wireless
                services to our valued customers.
              </p>
              <p className="text-gray-600 mb-6">
                At Wyncell Network, we understand that staying connected is essential in today's digital world. That's
                why we've made it our mission to provide reliable, affordable wireless services that keep you connected
                when you need it most.
              </p>
              <button className="bg-[#00B6D6] text-white px-6 py-2 rounded-full hover:bg-opacity-90 transition-colors">
                Learn more about us
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Customer Favorites */}
      <section className="bg-[#1E2A38] py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Customer Favorites</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[12.0, 15.0, 15.0].map((price, index) => (
              <div key={index} className="bg-white rounded-lg p-6 text-center">
                <div className="text-3xl font-bold mb-4">${price.toFixed(2)}</div>
                <p className="text-gray-600 mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <button className="bg-[#00B6D6] text-white px-6 py-2 rounded-full hover:bg-opacity-90 transition-colors">
                  Choose Package
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-[#00B6D6] py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white text-center mb-4">Why Wyncell?</h2>
          <h3 className="text-2xl text-white text-center mb-12">Read What Our Customers Are Saying</h3>
          <div className="relative max-w-2xl mx-auto">
            <motion.div
              key={currentTestimonial}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-white rounded-lg p-6"
            >
              <div className="flex items-center mb-4">
                <Image
                  src={testimonials[currentTestimonial].avatar || "/placeholder.svg"}
                  alt={testimonials[currentTestimonial].name}
                  width={48}
                  height={48}
                  className="rounded-full mr-4"
                />
                <div>
                  <div className="font-semibold">{testimonials[currentTestimonial].name}</div>
                  <div className="flex">
                    {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600">{testimonials[currentTestimonial].text}</p>
            </motion.div>
            <button
              onClick={() => setCurrentTestimonial((prev) => (prev > 0 ? prev - 1 : testimonials.length - 1))}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 text-white"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={() => setCurrentTestimonial((prev) => (prev < testimonials.length - 1 ? prev + 1 : 0))}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 text-white"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        </div>
      </section>

      {/* Latest News */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Latest News</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {newsItems.map((item, index) => (
              <div key={index} className="rounded-lg overflow-hidden shadow-lg">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  width={400}
                  height={250}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="font-semibold text-xl mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{item.date}</p>
                  <p className="text-gray-600">{item.excerpt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Activation Steps */}
      <section className="bg-[#00B6D6] py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12">Activation in only 4 steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {activationSteps.map((step, index) => (
              <div key={index} className="bg-white rounded-lg p-6">
                <div className="text-[#00B6D6] font-bold text-xl mb-2">Step {index + 1}</div>
                <p>{step}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Amazon Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Wyncell Telecom is now Available on Amazon</h2>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/amazon-logo-nmRkExoPYDMYJMku2tQxuZIuvvsYQX.png"
                alt="Amazon Logo"
                width={200}
                height={60}
                className="mb-6"
              />
              <ul className="list-disc list-inside mb-6">
                <li>All the same great coverage</li>
                <li>Same low prices</li>
                <li>All packages covered with Amazon protection</li>
              </ul>
              <button className="bg-[#00B6D6] text-white px-6 py-2 rounded-full hover:bg-opacity-90 transition-colors">
                Shop Now Today
              </button>
            </div>
            <div className="md:w-1/2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/amazon-package-nmRkExoPYDMYJMku2tQxuZIuvvsYQX.png"
                alt="Amazon Package"
                width={400}
                height={400}
                className="rounded-full"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <motion.div className="bg-gray-50 p-6 rounded-lg shadow-md" whileHover={{ y: -5 }} transition={{ duration: 0.2 }}>
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  )
}

