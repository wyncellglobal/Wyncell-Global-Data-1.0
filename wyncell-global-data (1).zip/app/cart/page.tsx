"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useTranslation } from "react-i18next"
import { motion } from "framer-motion"
import { Trash2 } from "lucide-react"

interface CartItem {
  id: number
  name: string
  price: number
  image: string
  quantity: number
  type: "plan" | "device"
}

export default function Cart() {
  const { t } = useTranslation()
  const [cartItems, setCartItems] = useState<CartItem[]>([])

  useEffect(() => {
    // In a real application, you would fetch the cart items from an API or local storage
    const mockCartItems: CartItem[] = [
      { id: 1, name: "10GB Data Plan - Spain", price: 29.99, image: "/images/esim.png", quantity: 1, type: "plan" },
      { id: 2, name: "iPhone 13", price: 799, image: "/images/devices/iphone-13.jpg", quantity: 1, type: "device" },
    ]
    setCartItems(mockCartItems)
  }, [])

  const updateQuantity = (id: number, newQuantity: number) => {
    setCartItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, quantity: Math.max(1, newQuantity) } : item)),
    )
  }

  const removeItem = (id: number) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id))
  }

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t("Cart")}</h1> {/* Update 1: Capitalized "Cart" */}
      {cartItems.length === 0 ? (
        <p>{t("cartEmpty")}</p>
      ) : (
        <>
          {cartItems.map((item) => (
            <motion.div
              key={item.id}
              className="flex items-center border-b border-gray-200 py-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Image
                src={item.image || "/placeholder.svg"}
                alt={item.name}
                width={80}
                height={80}
                className="rounded-lg mr-4"
              />
              <div className="flex-grow">
                <h2 className="text-lg font-semibold">{item.name}</h2>
                <p className="text-gray-600">${item.price.toFixed(2)}</p>
              </div>
              <div className="flex items-center">
                {item.type === "device" && (
                  <>
                    <button
                      className="px-2 py-1 bg-gray-200 rounded-l"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    >
                      -
                    </button>
                    <span className="px-4 py-1 bg-gray-100">{item.quantity}</span>
                    <button
                      className="px-2 py-1 bg-gray-200 rounded-r"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    >
                      +
                    </button>
                  </>
                )}
                <button
                  className="ml-4 text-red-500 hover:text-red-700"
                  onClick={() => removeItem(item.id)}
                  aria-label={t("remove")}
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </motion.div>
          ))}
          <div className="mt-8 text-right">
            <p className="text-xl font-semibold">
              {t("total")}:&nbsp;${total.toFixed(2)} {/* Update 2: Added a non-breaking space */}
            </p>
            <Link
              href="/checkout"
              className="mt-4 bg-[#00ACCD] text-white px-6 py-3 rounded-full hover:bg-[#0090AB] transition-colors inline-block"
            >
              {t("proceedToCheckout")}
            </Link>
          </div>
        </>
      )}
    </div>
  )
}

