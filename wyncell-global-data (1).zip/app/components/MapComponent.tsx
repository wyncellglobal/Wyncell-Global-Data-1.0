"use client"

import { useEffect, useRef, useState } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import type { Country } from "../data/countries"

interface MapComponentProps {
  selectedCountry: Country | null
}

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN || ""

export default function MapComponent({ selectedCountry }: MapComponentProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const marker = useRef<mapboxgl.Marker | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    if (!mapContainer.current || map.current) return

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/satellite-v9",
        center: [0, 20],
        zoom: 1.5,
        projection: "globe",
        interactive: false,
      })

      map.current.on("style.load", () => {
        const mapInstance = map.current
        if (!mapInstance) return

        mapInstance.setFog({
          "horizon-blend": 0.02,
          "space-color": "#000000",
          "star-intensity": 0.6,
        })

        // Add country boundaries source and layers
        mapInstance.addSource("country-boundaries", {
          type: "vector",
          url: "mapbox://mapbox.country-boundaries-v1",
        })

        // Add a background fill layer for the selected country
        mapInstance.addLayer({
          id: "country-fill",
          type: "fill",
          source: "country-boundaries",
          "source-layer": "country_boundaries",
          paint: {
            "fill-color": "#00ACCD",
            "fill-opacity": 0.2,
          },
          filter: ["==", ["get", "iso_3166_1"], ""],
        })

        // Add a glowing outline for the selected country
        mapInstance.addLayer({
          id: "country-border",
          type: "line",
          source: "country-boundaries",
          "source-layer": "country_boundaries",
          paint: {
            "line-color": "#00ACCD",
            "line-width": 2,
            "line-blur": 0.5,
            "line-opacity": 0.8,
          },
          filter: ["==", ["get", "iso_3166_1"], ""],
        })

        // Add a more prominent border
        mapInstance.addLayer({
          id: "country-border-glow",
          type: "line",
          source: "country-boundaries",
          "source-layer": "country_boundaries",
          paint: {
            "line-color": "#00ACCD",
            "line-width": 4,
            "line-blur": 4,
            "line-opacity": 0.4,
          },
          filter: ["==", ["get", "iso_3166_1"], ""],
        })

        setMapLoaded(true)
      })

      let rotationInterval: number | null = null

      const startRotation = () => {
        if (rotationInterval) return
        rotationInterval = window.setInterval(() => {
          if (map.current) {
            const currentCenter = map.current.getCenter()
            map.current.setCenter([currentCenter.lng + 0.1, currentCenter.lat])
          }
        }, 50)
      }

      const stopRotation = () => {
        if (rotationInterval) {
          clearInterval(rotationInterval)
          rotationInterval = null
        }
      }

      if (!selectedCountry) {
        startRotation()
      }

      return () => {
        stopRotation()
        if (map.current) {
          map.current.remove()
          map.current = null
        }
      }
    } catch (err) {
      console.error("Error initializing map:", err)
      setError("Failed to load the map. Please check your connection and try again.")
    }
  }, [selectedCountry])

  useEffect(() => {
    if (!mapLoaded || !map.current) return

    const updateMapForCountry = () => {
      const mapInstance = map.current
      if (!mapInstance) return

      if (selectedCountry && selectedCountry.lat && selectedCountry.lng) {
        // Update marker
        if (marker.current) {
          marker.current.remove()
        }

        // Create a custom cell tower icon element
        const el = document.createElement("div")
        el.className = "cell-tower-marker"
        el.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#00ACCD" stroke="#ffffff" stroke-width="1">
            <path d="M12 2L2 22h20L12 2z"/>
            <path d="M12 8v8"/>
            <path d="M8 16l8-4"/>
            <path d="M16 16l-8-4"/>
          </svg>
        `

        marker.current = new mapboxgl.Marker(el)
          .setLngLat([selectedCountry.lng, selectedCountry.lat])
          .addTo(mapInstance)

        // Update the country highlight
        mapInstance.setFilter("country-fill", ["==", ["get", "iso_3166_1"], selectedCountry.code])
        mapInstance.setFilter("country-border", ["==", ["get", "iso_3166_1"], selectedCountry.code])
        mapInstance.setFilter("country-border-glow", ["==", ["get", "iso_3166_1"], selectedCountry.code])

        // Fly to the country with padding to account for the info card
        mapInstance.flyTo({
          center: [selectedCountry.lng, selectedCountry.lat],
          zoom: 4,
          duration: 2000,
          padding: { left: 400, top: 0, right: 0, bottom: 0 },
        })
      } else {
        // Clear the country highlight
        mapInstance.setFilter("country-fill", ["==", ["get", "iso_3166_1"], ""])
        mapInstance.setFilter("country-border", ["==", ["get", "iso_3166_1"], ""])
        mapInstance.setFilter("country-border-glow", ["==", ["get", "iso_3166_1"], ""])

        if (marker.current) {
          marker.current.remove()
        }
        mapInstance.flyTo({
          center: [0, 20],
          zoom: 1.5,
          duration: 2000,
        })
      }
    }

    // Ensure the style is loaded before updating the map
    if (map.current.isStyleLoaded()) {
      updateMapForCountry()
    } else {
      map.current.once("style.load", updateMapForCountry)
    }
  }, [selectedCountry, mapLoaded])

  if (error) {
    return <div className="w-full h-full flex items-center justify-center bg-black text-white">{error}</div>
  }

  return <div ref={mapContainer} className="absolute inset-0 w-full h-full bg-black" />
}

