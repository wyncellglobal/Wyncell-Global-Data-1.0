"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useTranslation } from "react-i18next"
import { Globe, Languages, Menu, ChevronDown } from "lucide-react"

export default function SharedHeader() {
  const { t, i18n } = useTranslation()
  const [userCurrency, setUserCurrency] = useState("USD")
  const [isCurrencyDropdownOpen, setIsCurrencyDropdownOpen] = useState(false)
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const currencyDropdownRef = useRef<HTMLDivElement>(null)
  const languageDropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (currencyDropdownRef.current && !currencyDropdownRef.current.contains(event.target as Node)) {
        setIsCurrencyDropdownOpen(false)
      }
      if (languageDropdownRef.current && !languageDropdownRef.current.contains(event.target as Node)) {
        setIsLanguageDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng)
    setIsLanguageDropdownOpen(false)
  }

  const currencies = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    JPY: "¥",
  }

  return (
    <header className="relative z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center">
          <Link href="/" className="flex items-center mr-auto">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo%20Wyncell%20(2)-nmRkExoPYDMYJMku2tQxuZIuvvsYQX.png"
              alt="Wyncell Logo"
              width={240}
              height={60}
              className="h-16 w-auto"
              priority
            />
          </Link>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/plans" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
              {t("plans")}
            </Link>
            <Link
              href="/phones-and-devices"
              className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium"
            >
              {t("phonesAndDevices")}
            </Link>
            <Link href="/support" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
              {t("support")}
            </Link>
            <Link href="/esim-guide" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
              {t("esimGuide")}
            </Link>
            <div className="relative" ref={currencyDropdownRef}>
              <button
                className="flex items-center space-x-2 text-gray-800 hover:text-[#00ACCD] transition-colors font-medium"
                onClick={() => setIsCurrencyDropdownOpen(!isCurrencyDropdownOpen)}
              >
                <Globe size={20} />
                <span className="ml-2">{userCurrency}</span>
                <ChevronDown size={16} className="ml-1" />
              </button>
              {isCurrencyDropdownOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white border border-gray-300 rounded-lg shadow-lg">
                  {Object.entries(currencies).map(([currency, symbol]) => (
                    <button
                      key={currency}
                      className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                      onClick={() => {
                        setUserCurrency(currency)
                        setIsCurrencyDropdownOpen(false)
                      }}
                    >
                      {currency} ({symbol})
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="relative" ref={languageDropdownRef}>
              <button
                className="flex items-center space-x-2 text-gray-800 hover:text-[#00ACCD] transition-colors font-medium"
                onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
              >
                <Languages size={20} />
                <span className="ml-2">{i18n.language.toUpperCase()}</span>
                <ChevronDown size={16} className="ml-1" />
              </button>
              {isLanguageDropdownOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white border border-gray-300 rounded-lg shadow-lg">
                  <button
                    className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                    onClick={() => changeLanguage("en")}
                  >
                    English
                  </button>
                  <button
                    className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                    onClick={() => changeLanguage("es")}
                  >
                    Español
                  </button>
                </div>
              )}
            </div>
            <Link
              href="/signin"
              className="bg-[#00ACCD] text-white px-6 py-2 rounded-full hover:bg-[#0090AB] transition-colors font-medium"
            >
              {t("signIn")}
            </Link>
          </nav>
          <button className="md:hidden text-gray-800 ml-4" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            <Menu size={24} />
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-md">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/plans" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
                {t("plans")}
              </Link>
              <Link
                href="/phones-and-devices"
                className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium"
              >
                {t("phonesAndDevices")}
              </Link>
              <Link href="/support" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
                {t("support")}
              </Link>
              <Link href="/esim-guide" className="text-gray-800 hover:text-[#00ACCD] transition-colors font-medium">
                {t("esimGuide")}
              </Link>
              <Link
                href="/signin"
                className="bg-[#00ACCD] text-white px-4 py-2 rounded-full hover:bg-[#0090AB] transition-colors text-center font-medium"
              >
                {t("signIn")}
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}

