"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Search } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { countries, type Country } from "../data/countries"

interface CountrySelectorProps {
  onCountryChange: (country: string) => void
}

export default function CountrySelector({ onCountryChange }: CountrySelectorProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredCountries, setFilteredCountries] = useState(countries)
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null)
  const [isListOpen, setIsListOpen] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const listRef = useRef<HTMLUListElement>(null)

  useEffect(() => {
    const filtered = countries.filter((country) => country.name.toLowerCase().includes(searchTerm.toLowerCase()))
    setFilteredCountries(filtered)
    setIsListOpen(searchTerm.length > 0 && filtered.length > 0)
  }, [searchTerm])

  useEffect(() => {
    if (selectedCountry) {
      onCountryChange(selectedCountry.code)
    }
  }, [selectedCountry, onCountryChange])

  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country)
    setSearchTerm(country.name)
    setIsListOpen(false)
    inputRef.current?.blur()
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown" && isListOpen) {
      e.preventDefault()
      listRef.current?.firstElementChild?.querySelector("button")?.focus()
    }
  }

  return (
    <motion.div
      className="mt-6 relative"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <label htmlFor="country-search" className="block text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">
        Search Your Destination
      </label>
      <div className="relative">
        <div className="flex items-center">
          {selectedCountry && (
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
              <Image
                src={selectedCountry.flag || "/placeholder.svg"}
                alt={`${selectedCountry.name} flag`}
                width={20}
                height={15}
                className="rounded-sm"
              />
            </div>
          )}
          <input
            type="text"
            id="country-search"
            className={`w-full p-3 ${selectedCountry ? "pl-12" : "pl-3"} pr-10 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-wyncell-primary focus:border-wyncell-primary dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:focus:ring-wyncell-primary dark:focus:border-wyncell-primary`}
            placeholder="Type to search countries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onFocus={() => setIsListOpen(true)}
            onBlur={() => setTimeout(() => setIsListOpen(false), 200)}
            onKeyDown={handleKeyDown}
            ref={inputRef}
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        </div>
      </div>
      <AnimatePresence>
        {isListOpen && (
          <motion.ul
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto"
            ref={listRef}
          >
            {filteredCountries.map((country) => (
              <motion.li
                key={country.code}
                className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                whileHover={{ backgroundColor: "rgba(0, 172, 205, 0.1)" }}
              >
                <button
                  className="w-full text-left focus:outline-none focus:bg-gray-200 dark:focus:bg-gray-600 flex items-center"
                  onClick={() => handleCountrySelect(country)}
                >
                  <Image
                    src={country.flag || "/placeholder.svg"}
                    alt={`${country.name} flag`}
                    width={20}
                    height={15}
                    className="rounded-sm mr-3"
                  />
                  {country.name}
                </button>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

