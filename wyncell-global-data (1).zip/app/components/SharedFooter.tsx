import Link from "next/link"
import { useTranslation } from "react-i18next"

export default function SharedFooter() {
  const { t } = useTranslation()

  return (
    <footer className="relative z-20 w-full text-center py-4 bg-white shadow-md mt-auto">
      <p className="text-gray-600">
        © {new Date().getFullYear()} Wyncell Global Data |{" "}
        <Link href="/terms" className="text-[#00ACCD] hover:text-[#0090AB] transition-colors">
          {t("termsAndConditions")}
        </Link>
      </p>
    </footer>
  )
}

