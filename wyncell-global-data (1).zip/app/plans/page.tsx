"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { countries, type Country } from "../data/countries"
import { fetchPricingData, getPricingForCountry, type CountryPricing } from "../data/pricingData"
import { ChevronDown } from "lucide-react"
import dynamic from "next/dynamic"
import { fetchExchangeRates, getUserCurrency, currencySymbols } from "../utils/currencyUtils"
import PricingDisplay from "../components/PricingDisplay"
import { useTranslation } from "react-i18next"

const MapComponent = dynamic(() => import("../components/MapComponent"), {
  ssr: false,
  loading: () => (
    <div className="absolute inset-0 bg-black flex items-center justify-center">
      <div className="text-[#00ACCD]">Loading map...</div>
    </div>
  ),
})

export default function Plans() {
  const { t } = useTranslation()
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [userCurrency, setUserCurrency] = useState("USD")
  const [pricingData, setPricingData] = useState<CountryPricing[]>([])
  const dropdownRef = useRef<HTMLDivElement>(null)

  const filteredCountries = countries.filter((country) => country.name.toLowerCase().includes(searchTerm.toLowerCase()))

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  useEffect(() => {
    fetchExchangeRates()
    getUserCurrency().then(setUserCurrency)
    fetchPricingData().then(setPricingData)
  }, [])

  const getDataRatePerGB = (countryName: string): number => {
    const countryPricing = getPricingForCountry(pricingData, countryName)
    return countryPricing ? countryPricing.dataRatePerGB : 10 // Default to 10 if not found
  }

  return (
    <div className="relative min-h-screen w-full bg-black text-gray-800">
      {/* Background Map */}
      <div className="absolute inset-0 z-0">
        <MapComponent selectedCountry={selectedCountry} />
      </div>

      {/* Main content */}
      <main className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4">
        <motion.h1
          className="text-5xl font-bold text-white mb-8 text-shadow"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {t("selectCountry")}
        </motion.h1>

        <motion.div
          className="relative w-full max-w-md"
          ref={dropdownRef}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div
            className="w-full p-4 bg-white border border-gray-300 rounded-lg text-gray-800 flex justify-between items-center cursor-pointer shadow-md hover:shadow-lg transition-shadow"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          >
            {selectedCountry ? (
              <div className="flex items-center">
                <Image
                  src={selectedCountry.flag || "/placeholder.svg"}
                  alt={`${selectedCountry.name} flag`}
                  width={24}
                  height={16}
                  className="mr-2"
                />
                <span className="font-medium">{selectedCountry.name}</span>
              </div>
            ) : (
              <span className="text-gray-500">{t("chooseCountry")}</span>
            )}
            <ChevronDown size={20} className="text-gray-500" />
          </div>

          <AnimatePresence>
            {isDropdownOpen && (
              <motion.div
                className="absolute z-30 w-full mt-2 bg-white border border-gray-300 rounded-lg max-h-96 overflow-y-auto shadow-lg"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                <div className="p-2 border-b">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={t("chooseCountry")}
                    className="w-full p-2 border border-gray-300 rounded-md text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#00ACCD]"
                  />
                </div>
                {filteredCountries.map((country) => (
                  <div
                    key={country.code}
                    className="p-3 hover:bg-gray-100 cursor-pointer flex items-center"
                    onClick={() => {
                      setSelectedCountry(country)
                      setIsDropdownOpen(false)
                      setSearchTerm("")
                    }}
                  >
                    <Image
                      src={country.flag || "/placeholder.svg"}
                      alt={`${country.name} flag`}
                      width={24}
                      height={16}
                      className="mr-3"
                    />
                    <span className="text-gray-800">{country.name}</span>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {selectedCountry && (
          <PricingDisplay
            country={selectedCountry.name}
            countryCode={selectedCountry.code}
            dataRatePerGB={getDataRatePerGB(selectedCountry.name)}
            currency={userCurrency}
            currencySymbol={currencySymbols[userCurrency] || ""}
            onGetData={(plan, duration, totalPrice) => {
              console.log(`Selected plan: ${plan} for ${duration} days in ${selectedCountry.name}`)
              console.log(`Total price: ${currencySymbols[userCurrency]}${totalPrice.toFixed(2)} ${userCurrency}`)
              // You can add further logic here, such as opening a payment modal or navigating to a checkout page
            }}
          />
        )}
      </main>
    </div>
  )
}

